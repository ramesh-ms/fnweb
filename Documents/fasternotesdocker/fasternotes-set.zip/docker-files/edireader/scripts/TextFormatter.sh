CP=$EDIREADER_HOME/edireader-4.7.3.jar
java -cp $CP com.berryworks.edireader.formatter.Formatter $*
